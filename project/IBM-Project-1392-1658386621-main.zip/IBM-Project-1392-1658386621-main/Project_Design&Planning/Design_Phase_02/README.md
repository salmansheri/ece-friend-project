## PROJECT DESIGN & PLANNING
# DESIGN PHASE 02
    - CUSTOMER JOURNEY
    - DATA FLOW DIAGRAM
    - SOLUTION REQUIREMENTS
    - TECHNOLOGY STACK

## CUSTOMER JOURNEY:

[CUSTOMER JOURNEY LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/blob/main/Project_Design%26Planning/Design_Phase_02/Customer%20Journey/Customer%20Journey%20Map.pdf)

## DATA FLOW DIAGRAM :

[PROBLEM SOLUTION FIT LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/blob/main/Project_Design%26Planning/Design_Phase_02/Data%20Flow%20Dailgrams/data%20flow%20diagrams%20and%20user%20stories.pdf)

## SOLUTION REQUIREMENTS :

[SOLUTION REQUIREMENTS LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/tree/main/Project_Design%26Planning/Design_Phase_02/Solution%20Requirements)

## TECHNOLOGY STACK :

[TECHNOLOGY STACK LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/tree/main/Project_Design%26Planning/Design_Phase_02/Solution%20Requirements)