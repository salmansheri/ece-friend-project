## PROJECT DESIGN & PLANNING
# DESIGN PHASE 01
    - ARCHITECTURE
    - PROBLEM SOLUTION FIT
    - PROPOSED SOLUTION

## PROPOSED SOLUTION :

[PROPOSED SOLUTION LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/blob/main/Project_Design%26Planning/Design_Phase_01/Proposed%20Solution/Proposed%20Solution.pdf)

## PROBLEM SOLUTION FIT :

[PROBLEM SOLUTION FIT LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/blob/main/Project_Design%26Planning/Design_Phase_01/Problem%20Solution%20fit/Problem-Solution%20FIt.pdf)

## SOLUTION ARCHITECTURE :

[SOLUTION ARCHITECTURE LINK](https://github.com/IBM-EPBL/IBM-Project-1392-1658386621/blob/main/Project_Design%26Planning/Design_Phase_01/Architecture/Solution%20Architecture.pdf)
    