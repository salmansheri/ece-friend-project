# Assignment 03 🎯

## ChatBot link for DK Hospital Assistant !

ChatBot Web URL : [LINK](https://web-chat.global.assistant.watson.appdomain.cloud/preview.html?backgroundImageURL=https%3A%2F%2Fau-syd.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-d05024f0-2dbf-4ca1-9961-dc3402b37937%3A%3A512eb0a5-f099-4ba5-a2e3-e45f4c0d6275&integrationID=b8b38143-a95d-44b4-84f6-eef3ebb479f5&region=au-syd&serviceInstanceID=d05024f0-2dbf-4ca1-9961-dc3402b37937)

## Working with Cloud Storage