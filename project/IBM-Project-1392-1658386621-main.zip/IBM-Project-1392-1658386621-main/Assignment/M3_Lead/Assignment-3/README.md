# Assignment 03 🎯

## ChatBot link for Hospital Assistant !

ChatBot Web URL : [LINK](https://web-chat.global.assistant.watson.appdomain.cloud/preview.html?backgroundImageURL=https%3A%2F%2Feu-gb.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-23943f51-3c9f-4dd4-b395-2cc1e5838d03%3A%3A6c2d78aa-0ce2-4a53-8ef0-7799afecf6e1&integrationID=e66e5eca-4da1-450f-a242-de46d40da833&region=eu-gb&serviceInstanceID=23943f51-3c9f-4dd4-b395-2cc1e5838d03)

## Working with Cloud Storage