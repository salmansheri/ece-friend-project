# Assignment 03 🎯

## ChatBot link for Hospital Assistant !

ChatBot Web URL : [LINK](https://web-chat.global.assistant.watson.appdomain.cloud/preview.html?backgroundImageURL=https%3A%2F%2Feu-gb.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-2607efc7-375b-465c-9e61-399a0f694519%3A%3A19d9aaec-d13a-4a4f-b427-df1bebf0daf1&integrationID=66576f0c-5408-4edc-803b-d9de1f553e8b&region=eu-gb&serviceInstanceID=2607efc7-375b-465c-9e61-399a0f694519)

## Working with Cloud Storage