## ASSIGNMENT 04
    Working with Docker and Kubernetes 
    deploy as Nodeport

[NODEPORT LINK FLASK-APP](http://169.51.204.222:30037/)