# Assignment 03 🎯

## ChatBot link for Hospital Assistant !

ChatBot Web URL : [LINK](https://web-chat.global.assistant.watson.appdomain.cloud/preview.html?backgroundImageURL=https%3A%2F%2Feu-gb.assistant.watson.cloud.ibm.com%2Fpublic%2Fimages%2Fupx-8e1aea54-6a03-4458-a707-4160ea4f6d86%3A%3Aefd43f23-2b92-42d3-9587-cc1b975c8dd0&integrationID=3dcff0c6-50de-496d-a44c-843e32058eaa&region=eu-gb&serviceInstanceID=8e1aea54-6a03-4458-a707-4160ea4f6d86)
## Working with Cloud Storage
